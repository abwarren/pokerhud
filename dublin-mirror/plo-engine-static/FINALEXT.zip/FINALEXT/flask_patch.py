#!/usr/bin/env python3
"""
Flask API patch for W4P Remote Control - action state passthrough.

Apply on Dublin (52.16.14.220) to /opt/plo-equity/app.py
All changes are ADDITIVE - no existing fields removed or renamed.
Engine data stream (/engine/) is UNAFFECTED.

Patch instructions (4 locations in app.py):
"""

# ═══════════════════════════════════════════════════════════════════
# PATCH 1: get_or_create_table() - add 3 fields to table init
# ═══════════════════════════════════════════════════════════════════
#
# Find this block (around line 221-236):
#
#   def get_or_create_table(table_id):
#       if table_id not in _tables:
#           _tables[table_id] = {
#               ...
#               "dealer_seat":   None,
#           }
#
# ADD these 3 lines before the closing brace:
#
#               "active_seat":   None,
#               "active_player": None,
#               "buttons":       None,
#

# ═══════════════════════════════════════════════════════════════════
# PATCH 2: post_snapshot() - store action state from snapshot
# ═══════════════════════════════════════════════════════════════════
#
# Find this block (around line 510-514):
#
#       table["street"]      = payload.get("street")
#       table["pot_zar"]     = payload.get("pot_zar")
#       table["board"]       = payload.get("board", ...)
#       table["variant"]     = payload.get("variant", "plo")
#       table["dealer_seat"] = payload.get("dealer_seat")
#
# ADD these 3 lines immediately after:
#
#       table["active_seat"]   = payload.get("active_seat")
#       table["active_player"] = payload.get("active_player")
#       table["buttons"]       = payload.get("buttons")
#

# ═══════════════════════════════════════════════════════════════════
# PATCH 3: post_snapshot() seat storage - add per-seat action fields
# ═══════════════════════════════════════════════════════════════════
#
# Find this block (around line 525-534):
#
#           new_seats[seat_no] = {
#               "seat_no":    seat_no,
#               "name":       s.get("name"),
#               "stack_zar":  s.get("stack_zar"),
#               "hole_cards": s.get("hole_cards", []),
#               "status":     s.get("status", "empty"),
#               "is_dealer":  s.get("is_dealer", False),
#               "is_hero":    s.get("is_hero", False),
#               "last_seen":  ts,
#           }
#
# ADD these 3 fields before "last_seen":
#
#               "available_actions": s.get("available_actions", []),
#               "is_active":         s.get("is_active", False),
#               "bet":               s.get("bet", 0),
#

# ═══════════════════════════════════════════════════════════════════
# PATCH 4: _table_view() - include action state in API response
# ═══════════════════════════════════════════════════════════════════
#
# Find this block (around line 355-367):
#
#   def _table_view(table):
#       return {
#           "table_id":      table["table_id"],
#           ...
#           "collector_batch": _get_latest_collector_batch(),
#       }
#
# ADD these 3 fields before "collector_batch":
#
#           "active_seat":   table.get("active_seat"),
#           "active_player": table.get("active_player"),
#           "buttons":       table.get("buttons"),
#

# ═══════════════════════════════════════════════════════════════════
# PATCH 5: _build_seats_list() - add fields to empty seat placeholders
# ═══════════════════════════════════════════════════════════════════
#
# Find the empty seat placeholder block (around line 301-312):
#
#           out.append({
#               "seat_no":    seat_no,
#               "name":       None,
#               ...
#               "bot_id":     None,
#           })
#
# ADD these 3 fields before "bot_id":
#
#               "available_actions": [],
#               "is_active":  False,
#               "bet":        0,
#

# ═══════════════════════════════════════════════════════════════════
# VERIFICATION
# ═══════════════════════════════════════════════════════════════════
#
# After applying, restart Flask:
#   sudo systemctl restart plo-w4p
#
# Verify /api/table/latest now includes:
#   curl -s https://potlimitomaha.xyz/api/table/latest | python3 -m json.tool | grep -E 'active_seat|active_player|buttons|available_actions|is_active|"bet"'
#
# Expected: active_seat, active_player, buttons at table level;
#           available_actions, is_active, bet per seat
#
# Engine check - confirm /engine/ still works:
#   curl -s https://potlimitomaha.xyz/api/table/latest | python3 -m json.tool | grep -E 'table_id|street|pot_zar|board|seats'
#   (All existing fields must still be present and unchanged)
